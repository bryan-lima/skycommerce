using SkyCommerce.Fretes.Model;

namespace SkyCommerce.Fretes
{
    public static class DadosGerais
    {
        public static GeoCoordinate CentroDistribuicao { get; set; } = new GeoCoordinate(-23.6815315, -46.8754801);
    }
}
