﻿namespace SkyCommerce.Site.Models
{
    public class AtualizarQuantidadeCarrinhoViewModel
    {
        public string NomeUnico { get; set; }
        public int Quantidade { get; set; }
    }
}