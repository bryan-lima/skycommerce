﻿namespace SkyCommerce.Fretes.ViewModels
{
    public class PosicaoViewObject
    {
        public double Latitude { get; set; }
        public double Longitude { get; set; }
    }
}
