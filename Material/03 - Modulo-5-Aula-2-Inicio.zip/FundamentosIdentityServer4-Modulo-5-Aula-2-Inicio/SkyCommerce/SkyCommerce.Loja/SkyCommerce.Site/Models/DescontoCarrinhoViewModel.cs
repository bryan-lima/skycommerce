﻿namespace SkyCommerce.Site.Models
{
    public class DescontoCarrinhoViewModel
    {
        public string Cupom { get; set; }
    }
}